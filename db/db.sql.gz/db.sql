-- Adminer 4.8.0 MySQL 8.0.23 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `API`;
CREATE TABLE `API` (
  `API_ID` varchar(255) NOT NULL,
  `ISVALID` tinyint(1) NOT NULL,
  `CREATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`API_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `API` (`API_ID`, `ISVALID`, `CREATED`) VALUES
('f60ad03e-2be5-4a42-8c01-0454f0055008',	1,	'2021-04-15 09:08:59');

DROP TABLE IF EXISTS `API_COURSE`;
CREATE TABLE `API_COURSE` (
  `API_ID` varchar(255) NOT NULL,
  `COURSE_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`API_ID`,`COURSE_ID`),
  KEY `COURSE_ID` (`COURSE_ID`),
  CONSTRAINT `API_COURSE_ibfk_1` FOREIGN KEY (`COURSE_ID`) REFERENCES `COURSE` (`COURSE_ID`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `API_COURSE_ibfk_2` FOREIGN KEY (`API_ID`) REFERENCES `API` (`API_ID`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `API_COURSE` (`API_ID`, `COURSE_ID`) VALUES
('f60ad03e-2be5-4a42-8c01-0454f0055008',	'TIC1001');

DROP TABLE IF EXISTS `COURSE`;
CREATE TABLE `COURSE` (
  `COURSE_ID` varchar(255) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  PRIMARY KEY (`COURSE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `COURSE` (`COURSE_ID`, `TITLE`, `DESCRIPTION`) VALUES
('TIC1001',	'Introduction to Computing and Programming I',	'This module aims to (i) expose students to computing principles (including abstraction and composition), (ii) provide a broad introduction to key computing concepts (including computer organisation, operating systems, data management, distributed applications), and (iii) introduce students to basic programming methodologies and problem solving techniques through a simple structured programming language.');

DROP TABLE IF EXISTS `MATERIAL`;
CREATE TABLE `MATERIAL` (
  `MATERIAL_ID` varchar(255) NOT NULL,
  `SEQUENCE` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `COURSE_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`MATERIAL_ID`),
  KEY `COURSE_ID` (`COURSE_ID`),
  CONSTRAINT `MATERIAL_ibfk_1` FOREIGN KEY (`COURSE_ID`) REFERENCES `COURSE` (`COURSE_ID`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- 2021-04-15 09:10:01
